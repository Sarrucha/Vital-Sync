package com.example.vitialsync

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.telecom.Call
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsAnimationCompat
import androidx.fragment.app.Fragment
import com.example.vitialsync.api.RetrofitClient
import com.example.vitialsync.api.UserProfile
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class HomeFragment : Fragment(R.layout.fragment_home) {

    // UI Components
    private lateinit var tvDate: TextView
    private lateinit var tvWelcomeUser: TextView
    private lateinit var caloriesTextView: TextView
    private lateinit var heightTextView: TextView
    private lateinit var weightTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var stepsCountTextView: TextView
    private lateinit var distanceCoveredTextView: TextView
    private lateinit var waterCountTextView: TextView
    private lateinit var buttonIncrease: Button
    private lateinit var buttonDecrease: Button
    private lateinit var notificationBell: ImageButton

    private lateinit var userProfileManager: UserProfileManager


    // Variables
    private var stepCount = 0
    private var distanceInMeters = 0.0
    private var waterCount = 0
    private val stepDistance = 0.762 // Average step distance in meters
    private val handler = Handler()
    private var duration = 0

    companion object {
        const val REQUEST_CODE = 1001
        const val CHANNEL_ID = "fitness_channel"
    }

    // Runnable for step simulation
    private val runnable = object : Runnable {
        override fun run() {
            if (duration % 5 == 0) {
                stepCount++
                distanceInMeters = stepCount * stepDistance
                updateUI()

                // Show notification every 10 steps
                if (stepCount % 10 == 0) {
                    showNotification("Step Goal Reached", "You've reached $stepCount steps!")
                }
            }
            duration++
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Request notification permission
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_CODE
            )
        } else {
            createNotificationChannel()
        }

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        // Initialize UI Components
        tvDate = view.findViewById(R.id.tvDate)
        tvWelcomeUser = view.findViewById(R.id.tvWelcomeUser)
        caloriesTextView = view.findViewById(R.id.caloriesTextView)
        heightTextView = view.findViewById(R.id.heightTextView)
        weightTextView = view.findViewById(R.id.weightTextView)
        ageTextView = view.findViewById(R.id.ageTextView)
        stepsCountTextView = view.findViewById(R.id.steps_count)
        distanceCoveredTextView = view.findViewById(R.id.distance_covered)
        waterCountTextView = view.findViewById(R.id.water_count)
        buttonIncrease = view.findViewById(R.id.button_increase)
        buttonDecrease = view.findViewById(R.id.button_decrease)
        notificationBell = view.findViewById(R.id.notificationBell)

        // Set current date
        setCurrentDate()

        // Initialize UserProfileManager
        val userProfileManager = UserProfileManager(requireContext())

        // Retrieve and display user data
        val username = userProfileManager.getUsername()
        val age = userProfileManager.getAge()
        val height = userProfileManager.getHeight()
        val weight = userProfileManager.getWeight()

        tvWelcomeUser.text = getString(R.string.welcome_user, username)
        ageTextView.text = getString(R.string.age_label, age)
        heightTextView.text = getString(R.string.height_label, height)
        weightTextView.text = getString(R.string.weight_label, weight)

        // Calculate and display calories
        val calories = calculateCalories(age, height, weight)
        caloriesTextView.text = getString(R.string.calories_message, calories)

        // Button click listeners
        buttonIncrease.setOnClickListener {
            waterCount++
            updateWaterCountDisplay()
        }
        buttonDecrease.setOnClickListener {
            if (waterCount > 0) {
                waterCount--
                updateWaterCountDisplay()
            }
        }

        // Animation for notification bell
        notificationBell.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                notificationBell.startAnimation(shake)
            }
            false
        }

        // Start the step simulation
        handler.post(runnable)
    }


    private fun setCurrentDate() {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        tvDate.text = currentDate
    }

    private fun updateUI() {
        stepsCountTextView.text = getString(R.string.steps_count_format, stepCount)
        distanceCoveredTextView.text = getString(R.string.distance_covered_format, distanceInMeters)
    }

    private fun updateWaterCountDisplay() {
        waterCountTextView.text = getString(R.string.water_count_format, waterCount)
    }

    private fun showNotification(title: String, message: String) {
        val intent = Intent(requireContext(), MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager =
            requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Fitness Notifications"
            val channelDescription = "Channel for fitness app notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
                description = channelDescription
            }
            val notificationManager =
                requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                createNotificationChannel()
                Log.d("HomeFragment", "Notification permission granted")
            } else {
                Log.d("HomeFragment", "Notification permission denied.")
            }
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(runnable)
    }

    override fun onResume() {
        super.onResume()
        handler.post(runnable)
    }

    private fun calculateCalories(age: Int, height: Int, weight: Int): Int {
        return (10 * weight + 6.25 * height - 5 * age + 5).toInt()
    }
}