package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog

//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class BreakfastActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_breakfast)

        // Back button setup
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // English Breakfast button setup
        val englishBreakfastButton: ImageButton = findViewById(R.id.english_breakfast)
        englishBreakfastButton.setOnClickListener {
            // Show dialog with details using string resources
            showDetailsDialog(
                getString(R.string.english_breakfast_title),
                getString(R.string.english_breakfast_description)
            )
        }

        // Pancakes button setup
        val pancakesButton: ImageButton = findViewById(R.id.pancakes)
        pancakesButton.setOnClickListener {
            // Show dialog with details using string resources
            showDetailsDialog(
                getString(R.string.pancakes_title),
                getString(R.string.pancakes_description)
            )
        }
    }

    // Function to show a dialog with details
    private fun showDetailsDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
