package com.example.vitialsync

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class HealthGuideFragment : BaseFragment() {

    private lateinit var listView: ListView
    private lateinit var notificationBell: ImageButton
    private val handler = Handler()
    private val notificationRunnable = Runnable { sendAutomatedNotification() }

    companion object {
        const val REQUEST_CODE = 1001
        const val CHANNEL_ID = "health_guide_notifications"
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_health_guide, container, false)

        // Request notification permission
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_CODE)
        } else {
            createNotificationChannel() // Create notification channel if permission is granted
        }

        // Initialize the ListView and Notification Bell
        listView = view.findViewById(R.id.healthGuideListView)
        notificationBell = view.findViewById(R.id.notificationBell)

        // List of sections to display
        val sections = arrayOf(
            getString(R.string.recipes_section),
            getString(R.string.workout_section),
            getString(R.string.food_section)
        )

        // Adapter to bind the list of sections to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, sections)
        listView.adapter = adapter

        // Set a click listener for each item in the list
        listView.onItemClickListener = AdapterView.OnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), RecipeSectionActivity::class.java))
                1 -> startActivity(Intent(requireContext(), WorkoutSectionActivity::class.java))
                2 -> startActivity(Intent(requireContext(), FoodSectionActivity::class.java))
            }
        }

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            showNotification("Health Guide", "Check out our latest tips on wellness and nutrition!")
        }

        return view
    }

    // Function to create the notification channel
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Health Guide Notifications"
            val channelDescription = "Channel for health guide notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
                description = channelDescription
            }
            val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // Function to show a notification
    private fun showNotification(title: String, message: String) {
        val intent = Intent(requireContext(), MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // Replace with your app's notification icon
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, notification) // Unique ID for the notification
    }

    // Function to send an automated notification
    private fun sendAutomatedNotification() {
        showNotification("Health Reminder", "Don't forget to check your health tips today!")
        // Schedule the next notification (every 5 minutes, for example)
        handler.postDelayed(notificationRunnable, 5 * 60 * 1000) // 5 minutes
    }

    // Handle permission result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                createNotificationChannel() // Create channel if permission granted
            }
        }
    }

    // Start automated notifications when the fragment is visible
    override fun onResume() {
        super.onResume()
        // Start sending automated notifications
        handler.post(notificationRunnable)
    }

    // Stop automated notifications when the fragment is no longer visible
    override fun onPause() {
        super.onPause()
        // Stop sending notifications
        handler.removeCallbacks(notificationRunnable)
    }
}

