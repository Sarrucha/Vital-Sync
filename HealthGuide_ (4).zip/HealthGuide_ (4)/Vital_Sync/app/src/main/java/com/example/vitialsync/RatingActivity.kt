package com.example.vitialsync

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ImageButton
import android.widget.RatingBar
import android.widget.Toast

//Code Attribution
//This code was referenced from Medium
//https://uxplanet.org/how-to-design-user-rating-and-reviews-1b26c0208d3a
//The authors is Nick Babich
//https://medium.com/@101?source=post_page-----1b26c0208d3a--------------------------------
class RatingActivity : BaseActivity() {
    @SuppressLint("StringFormatMatches")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rating)

        // Reference to back button and rating bar
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val ratingBar: RatingBar = findViewById(R.id.ratingBar)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Set listener for rating changes
        ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            val message = getString(R.string. rating_message , rating) // Use string resource with formatting
            Toast.makeText( this , message, Toast. LENGTH_SHORT ).show()
        }
    }
}
