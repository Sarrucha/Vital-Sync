package com.example.vitialsync

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AlertDialog

//Code Attribution
//This code was referenced from GeekaforGeeks
//https://www.geeksforgeeks.org/build-a-recipe-app-using-mvvm-architecture-with-kotlin-in-android/
// The author name is GeeksForGeeks
//https://www.geeksforgeeks.org/build-a-recipe-app-using-mvvm-architecture-with-kotlin-in-android/
class RecipeSectionActivity : BaseActivity() {

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe_section)

        // Reference the Back Button, Notification Bell, and ListView
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val notificationBell: ImageButton = findViewById(R.id.notificationBell)
        val listView: ListView = findViewById(R.id.recipeListView)

        // Set click listener for the back button to navigate to the previous screen
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            // Show dialog when bell is clicked
            showNotificationDialog()
        }

        // List of recipe options
        val recipeOptions = arrayOf(
            getString(R.string.smoothies),
            getString(R.string.dinner),
            getString(R.string.lunch),
            getString(R.string.breakfast),
            getString(R.string.desserts)
        )

        // Adapter to bind the items to the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, recipeOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, SmoothiesActivity::class.java))
                1 -> startActivity(Intent(this, DinnerActivity::class.java))
                2 -> startActivity(Intent(this, LunchActivity::class.java))
                3 -> startActivity(Intent(this, BreakfastActivity::class.java))
                4 -> startActivity(Intent(this, DesertsActivity::class.java))
            }
        }
    }

    // Function to show a message dialog
    private fun showNotificationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Notifications")
            .setMessage("Healthy food fuels a healthy life! Try out a new recipe today and nourish your body with wholesome ingredients")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
