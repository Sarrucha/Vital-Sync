package com.example.vitialsync

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class RegistrationActivity : BaseActivity() {

    // Declare UI components
    private lateinit var logoImage: ImageView
    private lateinit var username: EditText
    private lateinit var email: EditText
    private lateinit var password: EditText
    private lateinit var termsCheckbox: CheckBox
    private lateinit var registerButton: Button
    private lateinit var signinLink: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        // Initialize UI components
        initializeUI()

        // Set up click listeners for buttons and text views
        setUpEventHandlers()
    }

    private fun initializeUI() {
        logoImage = findViewById(R.id.logoImage)
        username = findViewById(R.id.username)
        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        termsCheckbox = findViewById(R.id.terms_checkbox)
        registerButton = findViewById(R.id.register_button)
        signinLink = findViewById(R.id.signin_link)
    }

    private fun setUpEventHandlers() {
        registerButton.setOnClickListener {
            val usernameInput = username.text.toString().trim()
            val emailInput = email.text.toString().trim()
            val passwordInput = password.text.toString().trim()

            if (usernameInput.isEmpty() || emailInput.isEmpty() || passwordInput.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!termsCheckbox.isChecked) {
                Toast.makeText(this, "Please accept the terms and conditions", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save the username and password to SharedPreferences
            val sharedPreferences = getSharedPreferences("userProfile", MODE_PRIVATE)
            val editor = sharedPreferences.edit()
            editor.putString("username", usernameInput)
            editor.putString("password", passwordInput)
            editor.apply()

            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()

            // Navigate to the LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        signinLink.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}
