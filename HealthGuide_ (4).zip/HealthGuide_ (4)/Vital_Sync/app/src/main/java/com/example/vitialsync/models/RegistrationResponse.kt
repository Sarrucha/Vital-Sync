package com.example.vitialsync.models

data class RegistrationResponse(
    val username: String,
    val email: String,
    val password: String
)
