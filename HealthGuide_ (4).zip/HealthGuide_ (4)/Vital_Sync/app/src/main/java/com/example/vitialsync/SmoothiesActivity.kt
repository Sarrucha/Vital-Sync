package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog

//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class SmoothiesActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_smoothies)

        // Find the back button and set click listener
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Find the image buttons
        val button1: ImageButton = findViewById(R.id.banana1)
        val button2: ImageButton = findViewById(R.id.spinach)

        // Set click listener for the first image button
        button1.setOnClickListener {
            showDetailsDialog(getString(R.string.banana_smoothie_title), getString(R.string.banana_smoothie_details))
        }

// Set click listener for the second image button
        button2.setOnClickListener {
            showDetailsDialog(getString(R.string.spinach_smoothie_title), getString(R.string.spinach_smoothie_details))
        }
    }

    // Function to show a dialog with details
    private fun showDetailsDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()  // Dismiss the dialog when the user clicks "OK"
            }
            .show()
    }
}
