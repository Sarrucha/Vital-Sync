package com.example.vitialsync.api

data class UserProfile(
    val username: String,
    val age: Int,
    val height: Int,
    val weight: Int)
