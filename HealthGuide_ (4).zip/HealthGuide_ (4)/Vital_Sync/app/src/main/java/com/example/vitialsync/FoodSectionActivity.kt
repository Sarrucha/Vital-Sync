package com.example.vitialsync

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.appcompat.app.AlertDialog

//Code Attribution
// The code was referenced from GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/
//The author name is GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/

class FoodSectionActivity : BaseActivity() {

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_food_section)

        // Reference the Back Button, Notification Bell, and ListView
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val notificationBell: ImageButton = findViewById(R.id.notificationBell)
        val listView: ListView = findViewById(R.id.foodListView)

        // Set click listener for the back button to navigate to the previous screen
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            // Show dialog when bell is clicked
            showNotificationDialog()
        }

        // List of food categories
        val foodItems = arrayOf(
            getString(R.string.food_category_healthy_food),
            getString(R.string.food_category_power_bites),
            getString(R.string.food_category_body_building)
        )

        // Adapter to bind the food categories to the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, foodItems)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, HealthyFoodActivity::class.java))
                1 -> startActivity(Intent(this, PowerBitesActivity::class.java))
                2 -> startActivity(Intent(this, BodyBuildingActivity::class.java))
            }
        }
    }

    // Function to show a message dialog
    private fun showNotificationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Notifications")
            .setMessage("Hydrate, nourish, and thrive! Remember to drink enough water and fuel your body with balanced meals")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
