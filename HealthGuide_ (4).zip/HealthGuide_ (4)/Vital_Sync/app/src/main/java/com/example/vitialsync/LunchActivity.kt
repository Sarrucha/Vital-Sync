package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog

//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class LunchActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lunch)

        // Back button setup
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Avocado and Bacon Sandwich button setup
        val avocadoBaconSandwichButton: ImageButton = findViewById(R.id.avocado_bacon_sandwich)
        avocadoBaconSandwichButton.setOnClickListener {
            // Show dialog with details
            showDetailsDialog(getString(R.string.avocado_bacon_sandwich_title), getString(R.string.avocado_bacon_sandwich_details))
        }

        // Kota button setup
        val kotaButton: ImageButton = findViewById(R.id.kota)
        kotaButton.setOnClickListener {
            // Show dialog with details
            showDetailsDialog(getString(R.string.kota_title), getString(R.string.kota_details))
        }
    }

    // Function to show a dialog with details
    private fun showDetailsDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
