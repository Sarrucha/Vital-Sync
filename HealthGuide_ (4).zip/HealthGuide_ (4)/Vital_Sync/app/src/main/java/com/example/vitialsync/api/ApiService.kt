package com.example.vitialsync.api


import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Body

interface ApiService {

    // Example of a GET request to fetch user profile data
    @GET("user/profile")
    fun getUserProfile(): Call<UserProfile>

    // Example of a POST request to update user profile data
    @POST("user/profile")
    fun updateUserProfile(@Body userProfile: UserProfile): Call<UserProfile>
}