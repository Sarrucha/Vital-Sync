package com.example.vitialsync

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

open class BaseActivity : AppCompatActivity() {


    override fun attachBaseContext(newBase: Context) {
        val locale = getSavedLocale(newBase)
        val context = updateLocale(newBase, locale)
        super.attachBaseContext(context)
    }

    // Method to update the locale in the context
    private fun updateLocale(context: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)

        return context.createConfigurationContext(config)
    }

    // Method to retrieve the saved locale
    private fun getSavedLocale(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)
        return sharedPreferences.getString("Selected_Language", "en") ?: "en" // Default to English
    }


    // Method to save the selected locale
    protected fun saveLocale(languageCode: String) {
        val sharedPreferences = getSharedPreferences("Settings", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("Selected_Language", languageCode)
        editor.apply()
    }

    // Method to dynamically apply locale changes to the app without restarting
    protected fun updateLocaleAndUI(languageCode: String) {
        saveLocale(languageCode)
        recreate() // Recreate the activity to apply the new language
    }

}