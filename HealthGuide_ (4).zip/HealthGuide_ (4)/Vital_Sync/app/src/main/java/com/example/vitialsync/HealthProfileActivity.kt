package com.example.vitialsync

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner

class HealthProfileActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_health_profile)

        // Get references to input fields
        val ageInput: EditText = findViewById(R.id.ageInput)
        val heightInput: EditText = findViewById(R.id.heightInput)
        val weightInput: EditText = findViewById(R.id.weightInput)

        // Find the button by its ID
        val navigateToMainButton: Button = findViewById(R.id.clickHereButton)

        // Set the click listener to save data and navigate to MainActivity
        navigateToMainButton.setOnClickListener {
            // Save user inputs to SharedPreferences
            val sharedPreferences = getSharedPreferences("userProfile", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            val age = ageInput.text.toString()
            val height = heightInput.text.toString()
            val weight = weightInput.text.toString()

            editor.putString("age", age)
            editor.putString("height", height)
            editor.putString("weight", weight)

            // Commit changes to SharedPreferences
            editor.apply()
            // Inside your onCreate or onViewCreated method
            val sexInputSpinner: Spinner = findViewById(R.id.sexInputSpinner)

            // Create an ArrayAdapter using the string array and a default spinner layout
            ArrayAdapter.createFromResource(
                this, // Use 'requireContext()' if inside a Fragment
                R.array.sex_options,
                android.R.layout.simple_spinner_item
            ).also { adapter ->
                // Specify the layout to use when the list of choices appears
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                // Apply the adapter to the spinner
                sexInputSpinner.adapter = adapter
            }


            // Navigate to MainActivity with data
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra("EXTRA_AGE", age)
                putExtra("EXTRA_HEIGHT", height)
                putExtra("EXTRA_WEIGHT", weight)
            }
            startActivity(intent)
        }
    }
}
