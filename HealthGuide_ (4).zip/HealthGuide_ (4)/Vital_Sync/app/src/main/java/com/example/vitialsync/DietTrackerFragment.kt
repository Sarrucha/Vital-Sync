package com.example.vitialsync

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.app.NotificationCompat

class DietTrackerFragment : BaseFragment() {

    private var totalCaloriesAllowed = 2500
    private var currentCalories = 0
    private var totalCarbsAllowed = 300
    private var currentCarbs = 0
    private var totalProteinAllowed = 150
    private var currentProtein = 0
    private var totalFatsAllowed = 70
    private var currentFats = 0
    private val breakfastCalories = 345
    private val lunchCalories = 545
    private val dinnerCalories = 895
    private val breakfastCarbs = 45
    private val lunchCarbs = 60
    private val dinnerCarbs = 80
    private val breakfastProtein = 20
    private val lunchProtein = 30
    private val dinnerProtein = 25
    private val breakfastFats = 15
    private val lunchFats = 25
    private val dinnerFats = 35
    private lateinit var addBreakfastButton: ImageButton
    private lateinit var addLunchButton: ImageButton
    private lateinit var addDinnerButton: ImageButton
    private lateinit var remainingCaloriesTextView: TextView
    private lateinit var eatenCaloriesTextView: TextView
    private lateinit var burnedCaloriesTextView: TextView
    private lateinit var carbsProgressBar: ProgressBar
    private lateinit var proteinProgressBar: ProgressBar
    private lateinit var fatsProgressBar: ProgressBar

    companion object {
        const val REQUEST_CODE = 1001
        const val CHANNEL_ID = "fitness_channel"
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_diet_tracker, container, false)

        addBreakfastButton = view.findViewById(R.id.addbuttonb)
        addLunchButton = view.findViewById(R.id.add_button_l)
        addDinnerButton = view.findViewById(R.id.add_button_d)
        remainingCaloriesTextView = view.findViewById(R.id.remainingCaloriesTextView)
        eatenCaloriesTextView = view.findViewById(R.id.eatenCaloriesTextView)
        burnedCaloriesTextView = view.findViewById(R.id.burnedCaloriesTextView)
        carbsProgressBar = view.findViewById(R.id.carbsProgressBar)
        proteinProgressBar = view.findViewById(R.id.proteinProgressBar)
        fatsProgressBar = view.findViewById(R.id.fatsProgressBar)

        updateRemainingCalories()
        addBreakfastButton.setOnClickListener {
            addMeal(breakfastCalories, breakfastCarbs, breakfastProtein, breakfastFats)
        }
        addLunchButton.setOnClickListener {
            addMeal(lunchCalories, lunchCarbs, lunchProtein, lunchFats)
        }
        addDinnerButton.setOnClickListener {
            addMeal(dinnerCalories, dinnerCarbs, dinnerProtein, dinnerFats)
        }

        // Create notification channel when fragment is opened
        createNotificationChannel()
        showNotification("Welcome to Diet Tracker", "Track your daily calories and nutrients!")

        return view
    }

    private fun addMeal(calories: Int, carbs: Int, protein: Int, fats: Int) {
        if (currentCalories + calories <= totalCaloriesAllowed) {
            currentCalories += calories
            currentCarbs += carbs
            currentProtein += protein
            currentFats += fats
            updateRemainingCalories()
            updateProgressBars()
        }
        checkIfCaloriesExceeded()
    }

    private fun updateRemainingCalories() {
        val remainingCalories = totalCaloriesAllowed - currentCalories
        remainingCaloriesTextView.text = remainingCalories.toString()
        eatenCaloriesTextView.text = "$currentCalories kcal"
    }

    private fun updateProgressBars() {
        carbsProgressBar.max = totalCarbsAllowed
        carbsProgressBar.progress = currentCarbs
        proteinProgressBar.max = totalProteinAllowed
        proteinProgressBar.progress = currentProtein
        fatsProgressBar.max = totalFatsAllowed
        fatsProgressBar.progress = currentFats
    }

    private fun checkIfCaloriesExceeded() {
        if (currentCalories >= totalCaloriesAllowed) {
            disableAllAddButtons()
            showNotification("Calorie Limit Exceeded", "You have reached your calorie limit for the day!")
        }
    }

    private fun disableAllAddButtons() {
        addBreakfastButton.isEnabled = false
        addLunchButton.isEnabled = false
        addDinnerButton.isEnabled = false
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Fitness Notifications"
            val channelDescription = "Channel for fitness app notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
                description = channelDescription
            }
            val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun showNotification(title: String, message: String) {
        Log.d("DietTrackerFragment", "Notification created")
        val intent = Intent(requireContext(), MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, notification)
        Log.d("DietTrackerFragment", "Notification shown successfully")
    }
}