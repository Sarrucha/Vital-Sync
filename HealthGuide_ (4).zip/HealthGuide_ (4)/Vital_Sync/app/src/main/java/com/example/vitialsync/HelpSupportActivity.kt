package com.example.vitialsync

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast

//Code Attribution
//This code was referenced from GrowthDot
//https://growthdot.com/designs-for-your-help-center/
//The author name is Natalie Zhontsa
//Natalia Zhontsa@growthdot.com
class HelpSupportActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_support)

        // Back button to navigate to the previous screen
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Contact Us button
        val contactUsButton: Button = findViewById(R.id.contact_us_button)
        contactUsButton.setOnClickListener {
            // Create an email intent
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "message/rfc822"  // MIME type for email
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("support@vital-sync.com"))
            intent.putExtra(
                Intent.EXTRA_SUBJECT,
                getString(R.string.email_subject)
            ) // Use string resource for subject

            // Pre-fill the email body with text from resources
            intent.putExtra(
                Intent.EXTRA_TEXT,
                getString(R.string.email_body)
            ) // Use string resource for body

            // Use a chooser for sending email
            try {
                startActivity(
                    Intent.createChooser(
                        intent,
                        getString(R.string.email_chooser_title)
                    )
                ) // Use string resource for chooser title
            } catch (e: android.content.ActivityNotFoundException) {
                // Show a message if no email app is available
                Toast.makeText(this, getString(R.string.no_email_app_message), Toast.LENGTH_SHORT)
                    .show() // Use string resource for toast message
            }
        }

    }
}
