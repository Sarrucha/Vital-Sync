package com.example.vitialsync

class FoodItemAdapter {
}