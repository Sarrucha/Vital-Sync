package com.example.vitialsync

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.TimePicker
import android.widget.Toast
import androidx.core.app.NotificationCompat

class SleepingModeActivity : BaseActivity() {

    companion object {
        const val CHANNEL_ID = "sleeping_mode_channel"
    }

    private lateinit var bedtimePicker: TimePicker
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sleeping_mode)

        // Initialize the back button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener { onBackPressed() }

        // Initialize the TimePicker and Save button
        bedtimePicker = findViewById(R.id.bedtimePicker)
        saveButton = findViewById(R.id.saveButton)

        // Set TimePicker to 24-hour view
        bedtimePicker.setIs24HourView(true)

        // Handle the Save button click
        saveButton.setOnClickListener {
            val hour = bedtimePicker.hour
            val minute = bedtimePicker.minute
            Toast.makeText(this, "Bedtime set for $hour:$minute", Toast.LENGTH_SHORT).show()

            // Show bedtime reminder notification
            createNotificationChannel()
            showBedtimeReminderNotification()
        }
    }

    // Function to create the notification channel
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Sleeping Mode Reminders"
            val descriptionText = "Reminders for your ideal bedtime"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // Function to show bedtime reminder notification
    private fun showBedtimeReminderNotification() {
        val intent = Intent(this, SleepingModeActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // Update with your app's icon
            .setContentTitle("Time to Wind Down")
            .setContentText("Set your ideal bedtime to receive reminders and prepare for restful sleep.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, notification) // Unique ID for notification
    }
}
