package com.example.vitialsync

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView

// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class PrivacySecurityActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_security)

        // Reference the Back Button and ListView
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val listView: ListView = findViewById(R.id.privacySecurityListView)

        // Set click listener for the back button to navigate to the previous screen
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // List of options for Privacy and Security
        val privacySecurityOptions = arrayOf(
            getString(R.string.biometrics),
            getString(R.string.privacy_consent),
            getString(R.string.security_consent),
            getString(R.string.consent_and_permission)
        )

        // Adapter to bind the options to the ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, privacySecurityOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, BiometricsActivity::class.java))  // Navigate to Biometrics Activity
                1 -> startActivity(Intent(this, PrivacyConsentActivity::class.java)) // Navigate to Privacy Consent Activity
                2 -> startActivity(Intent(this, SecurityConsentActivity::class.java)) // Navigate to Security Consent Activity
                3 -> startActivity(Intent(this, ConsentPermissionActivity::class.java)) // Navigate to Consent and Permission Activity
            }
        }
    }
}
