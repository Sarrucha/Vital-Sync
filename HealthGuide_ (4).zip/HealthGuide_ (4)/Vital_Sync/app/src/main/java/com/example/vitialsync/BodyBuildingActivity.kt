package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton
//Code Attribution
// The code was referenced from GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/
//The author name is GeeksforGeeks
//https://www.geeksforgeeks.org/bottom-navigation-bar-in-android-using-kotlin/
class BodyBuildingActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_body_building)

        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }
    }
}
