package com.example.vitialsync

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.ListView
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class SettingsFragment : BaseFragment() {

    companion object {
        const val REQUEST_CODE = 1001
        const val CHANNEL_ID = "fitness_channel"
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        // Reference the ListView
        val listView: ListView = view.findViewById(R.id.settingsListView)

        // List of settings options
        val settingsOptions = arrayOf(
            getString(R.string.setting_sleeping_mode),
            getString(R.string.setting_customisation_options),
            getString(R.string.setting_privacy_security),
            getString(R.string.setting_help_support),
            getString(R.string.setting_rating)
        )

        // Adapter to bind the settings options to the ListView
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_list_item_1, settingsOptions)
        listView.adapter = adapter

        // Set click listener for each item in the list
        listView.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(requireContext(), SleepingModeActivity::class.java))
                1 -> startActivity(Intent(requireContext(), CustomisationOptionsActivity::class.java))
                2 -> startActivity(Intent(requireContext(), PrivacySecurityActivity::class.java))
                3 -> startActivity(Intent(requireContext(), HelpSupportActivity::class.java))
                4 -> startActivity(Intent(requireContext(), RatingActivity::class.java))
            }
        }

        // Reference the Notification Bell
        val notificationBell: ImageButton = view.findViewById(R.id.notificationBell)

        // Set touch listener to simulate hover effect
        notificationBell.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_DOWN -> {
                    // Apply shake animation
                    val shake = AnimationUtils.loadAnimation(requireContext(), R.anim.shake)
                    notificationBell.startAnimation(shake)
                }
            }
            false
        }

        // Set click listener for the notification bell
        notificationBell.setOnClickListener {
            showNotification("Settings Notification", "Check out the latest updates in your settings!")
        }

        // Check and request notification permission
        if (ContextCompat.checkSelfPermission(requireContext(), android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQUEST_CODE)
        } else {
            createNotificationChannel()
        }

        // Show automated notification when the fragment is created
        showNotification("Welcome to Settings", "Explore the options to customize your experience!")

        return view
    }

    // Function to create the notification channel
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "Fitness Notifications"
            val channelDescription = "Channel for fitness app notifications"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, channelName, importance).apply {
                description = channelDescription
            }
            val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // Function to show a notification
    private fun showNotification(title: String, message: String) {
        val intent = Intent(requireContext(), MainActivity::class.java) // Replace with your desired activity
        val pendingIntent = PendingIntent.getActivity(
            requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(requireContext(), CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification) // Replace with your app's notification icon
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, notification) // The '1' is a unique ID for the notification
    }

    // Handle the result of the permission request
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, create notification channel
                createNotificationChannel()
            } else {
                // Permission denied, you may want to inform the user
            }
        }
    }
}

