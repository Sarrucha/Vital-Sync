package com.example.vitialsync // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class CardioVascularActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cardio_vascular) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImageCardio: ImageView = findViewById(R.id.imageBeginnerCardio)
        val intermediateImageCardio: ImageView = findViewById(R.id.imageIntermediateCardio)
        val advancedImageCardio: ImageView = findViewById(R.id.imageAdvancedCardio)

        // Set click listener for the beginner cardio image button
        beginnerImageCardio.setOnClickListener {
            showDetailsDialog(
                getString(R.string.beginner_cardio_title),
                getString(R.string.beginner_cardio_description)
            )
        }

// Set click listener for the intermediate cardio image button
        intermediateImageCardio.setOnClickListener {
            showDetailsDialog(
                getString(R.string.intermediate_cardio_title),
                getString(R.string.intermediate_cardio_description)
            )
        }

// Set click listener for the advanced cardio image button
        advancedImageCardio.setOnClickListener {
            showDetailsDialog(
                getString(R.string.advanced_cardio_title),
                getString(R.string.advanced_cardio_description)
            )
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
