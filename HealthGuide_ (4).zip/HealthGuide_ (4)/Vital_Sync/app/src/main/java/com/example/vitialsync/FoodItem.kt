package com.example.vitialsync

class FoodItem {
}