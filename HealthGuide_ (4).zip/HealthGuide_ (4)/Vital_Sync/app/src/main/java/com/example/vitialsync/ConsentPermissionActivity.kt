package com.example.vitialsync

import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.TextView

// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class ConsentPermissionActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consent_permission)

        // Ensure this ID matches the one in the layout file
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Load the animation
        val titleTextView: TextView = findViewById(R.id.consent_permission_title)
        val fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in)

        // Apply the animation to the title TextView
        titleTextView.startAnimation(fadeInAnimation)
    }
}
