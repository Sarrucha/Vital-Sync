package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog

//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class DesertsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deserts)

        // Back button setup
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }

        // Chocolate Cake button setup
        val chocolateCakeButton: ImageButton = findViewById(R.id.chocolate_cake)
        chocolateCakeButton.setOnClickListener {
            // Show dialog with details using string resources
            showDetailsDialog(
                getString(R.string.chocolate_cake_title),
                getString(R.string.chocolate_cake_description)
            )
        }

// Malva Pudding button setup
        val malvaPuddingButton: ImageButton = findViewById(R.id.malva_pudding)
        malvaPuddingButton.setOnClickListener {
            // Show dialog with details using string resources
            showDetailsDialog(
                getString(R.string.malva_pudding_title),
                getString(R.string.malva_pudding_description)
            )
        }
    }

    // Function to show a dialog with details
    private fun showDetailsDialog(title: String, message: String) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
