package com.example.vitialsync

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

//Code Attribution
//This code was referenced from AndroidDevelopers
//https://developer.android.com/training/data-storage/room/defining-data

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    // Creates the table when app is first launched
    override fun onCreate(db: SQLiteDatabase?){
        val createUserTable = "CREATE TABLE $TABLE_USER(" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_USERNAME TEXT," +
                "$COLUMN_EMAIL TEXT," +
                "$COLUMN_PASSWORD TEXT)"
        db?.execSQL(createUserTable)

        // Create health guide table
        val createHealthGuideTable = "CREATE TABLE $TABLE_HEALTH_GUIDE (" +
                "$COLUMN_GUIDE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_TITLE TEXT, " +
                "$COLUMN_DESCRIPTION TEXT)"
        db?.execSQL(createHealthGuideTable)

        // Create profile table
        val createProfileTable = "CREATE TABLE $TABLE_PROFILE (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_AGE TEXT, " +
                "$COLUMN_HEIGHT TEXT, " +
                "$COLUMN_WEIGHT TEXT, " +
                "$COLUMN_SEX TEXT)"
        db?.execSQL(createProfileTable)

        // Create Recipes Table
        val createRecipesTable = ("CREATE TABLE $TABLE_RECIPES (" +
                "$COLUMN_RECIPE_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_INGREDIENTS TEXT, " +
                "$COLUMN_INSTRUCTIONS TEXT)")
        db?.execSQL(createRecipesTable)

        // Create Workouts Table
        val createWorkoutsTable = ("CREATE TABLE $TABLE_WORKOUTS (" +
                "$COLUMN_WORKOUT_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_TITLE TEXT, " +
                "$COLUMN_DESCRIPTION TEXT)")
        db?.execSQL(createWorkoutsTable)

        // Create Food Table
        val createFoodTable = ("CREATE TABLE $TABLE_FOOD (" +
                "$COLUMN_FOOD_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_TITLE TEXT, " +
                "$COLUMN_BENEFITS TEXT, " +
                "$COLUMN_CATEGORY TEXT)")
        db?.execSQL(createFoodTable)

    }

    // Upgrades the db is the schema changes
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USER")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_HEALTH_GUIDE")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_PROFILE")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_RECIPES")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_WORKOUTS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_FOOD")
        onCreate(db)
    }

    fun addHealthGuide(title: String, description: String): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_TITLE, title)
            put(COLUMN_DESCRIPTION, description)
        }
        return db.insert(TABLE_HEALTH_GUIDE, null, contentValues)
    }

    fun getAllHealthGuides(): Cursor {
        val db = this.readableDatabase
        return db.query(TABLE_HEALTH_GUIDE, null, null, null, null, null, null)
    }

    // Method to add profile data
    fun addProfile(age: String, height: String, weight: String, sex: String): Long {
        val db = this.writableDatabase
        val contentValues = ContentValues().apply {
            put(COLUMN_AGE, age)
            put(COLUMN_HEIGHT, height)
            put(COLUMN_WEIGHT, weight)
            put(COLUMN_SEX, sex)
        }
        return db.insert(TABLE_PROFILE, null, contentValues)
    }

    // Method to get profile data
    fun getProfile(): Cursor {
        val db = this.readableDatabase
        return db.query(TABLE_PROFILE, null, null, null, null, null, null)
    }

    // Insert Recipe
    fun insertRecipe(title: String, ingredients: String, instructions: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TITLE, title)
        values.put(COLUMN_INGREDIENTS, ingredients)
        values.put(COLUMN_INSTRUCTIONS, instructions)
        db.insert(TABLE_RECIPES, null, values)
        db.close()
    }

    // Retrieve all Recipes
    fun getAllRecipes(): Cursor {
        val db = this.readableDatabase
        return db.query(TABLE_RECIPES, null, null, null, null, null, null)
    }

    // Insert Workout
    fun insertWorkout(title: String, description: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TITLE, title)
        values.put(COLUMN_DESCRIPTION, description)
        db.insert(TABLE_WORKOUTS, null, values)
        db.close()
    }

    // Retrieve all Workouts
    fun getAllWorkouts(): Cursor {
        val db = this.readableDatabase
        return db.query(TABLE_WORKOUTS, null, null, null, null, null, null)
    }

    // Insert Food
    fun insertFood(title: String, benefits: String, category: String) {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TITLE, title)
        values.put(COLUMN_BENEFITS, benefits)
        values.put("category", category) // Add category to values
        db.insert(TABLE_FOOD, null, values)
        db.close()
    }

    // Retrieve all Food items
    fun getAllFoods(): Cursor {
        val db = this.readableDatabase
        return db.query(
            TABLE_FOOD,
            null,
            null,
            null,
            null,
            null,
            null
        )
    }

    fun getFoodsByCategory(category: String): Cursor {
        val db = this.readableDatabase
        return db.query(
            TABLE_FOOD,
            null,
            "category = ?",
            arrayOf(category),
            null,
            null,
            null
        )
    }

    companion object {
        private const val DATABASE_NAME = "HealthGuide.db"
        private const val DATABASE_VERSION = 1

        const val TABLE_USER = "user"
        const val COLUMN_ID = "id"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_EMAIL = "email"
        const val COLUMN_PASSWORD = "password"

        const val TABLE_PROFILE = "profile"
        const val COLUMN_AGE = "age"
        const val COLUMN_HEIGHT = "height"
        const val COLUMN_WEIGHT = "weight"
        const val COLUMN_SEX = "sex"

        const val TABLE_HEALTH_GUIDE = "health_guide"
        const val COLUMN_GUIDE_ID = "guide_id"
        const val COLUMN_TITLE = "title"
        const val COLUMN_DESCRIPTION = "description"

        const val TABLE_RECIPES = "recipes"
        const val COLUMN_RECIPE_ID = "recipe_id"
        const val COLUMN_INGREDIENTS = "ingredients"
        const val COLUMN_INSTRUCTIONS = "instructions"

        const val TABLE_WORKOUTS = "workouts"
        const val COLUMN_WORKOUT_ID = "workout_id"

        const val TABLE_FOOD = "food"
        const val COLUMN_FOOD_ID = "food_id"
        const val COLUMN_BENEFITS = "benefits"
        const val COLUMN_CATEGORY = "category"

    }

}