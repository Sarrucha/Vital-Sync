package com.example.vitialsync // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class LowerBodyActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lower_body) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImageLowerBody: ImageView = findViewById(R.id.imageBeginnerLowerBody)
        val intermediateImageLowerBody: ImageView = findViewById(R.id.imageIntermediateLowerBody)
        val advancedImageLowerBody: ImageView = findViewById(R.id.imageAdvancedLowerBody)

        // Beginner Lower Body button setup
        beginnerImageLowerBody.setOnClickListener {
            showDetailsDialog(getString(R.string.beginner_lower_body_title), getString(R.string.beginner_lower_body_details))
        }

// Intermediate Lower Body button setup
        intermediateImageLowerBody.setOnClickListener {
            showDetailsDialog(getString(R.string.intermediate_lower_body_title), getString(R.string.intermediate_lower_body_details))
        }

// Advanced Lower Body button setup
        advancedImageLowerBody.setOnClickListener {
            showDetailsDialog(getString(R.string.advanced_lower_body_title), getString(R.string.advanced_lower_body_details))
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
