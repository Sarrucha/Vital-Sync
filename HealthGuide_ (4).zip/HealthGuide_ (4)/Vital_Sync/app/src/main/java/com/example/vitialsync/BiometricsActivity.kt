package com.example.vitialsync

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.ToggleButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

// Code Attribution
//This code was referenced from CloudDevops
//https://clouddevs.com/kotlin/secure-coding/
// The author name is Victor
//https://clouddevs.com/kotlin/secure-coding/
class BiometricsActivity :  BaseActivity() {

    private lateinit var promptManager: BiometricPromptManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_biometrics)

        promptManager = BiometricPromptManager(this) // Initialize BiometricPromptManager

        // Initialize UI elements
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        val toggleButton: ToggleButton = findViewById(R.id.toggle_button)
        val authenticateButton: Button = findViewById(R.id.authenticate_button)
        val biometricInfoTextView: TextView = findViewById(R.id.biometric_info_text)

        // Register the activity result for biometric enrollment
        val enrollLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            // Handle the result from the enrollment activity if necessary
            println("Activity result: $result")
        }

        // Collect biometric prompt results
        lifecycleScope.launch {
            promptManager.promptResults.collect { result ->
                biometricInfoTextView.text = when (result) {
                    is BiometricPromptManager.BiometricResult.AuthenticationError -> result.error
                    BiometricPromptManager.BiometricResult.AuthenticationFailed -> "Authentication Failed"
                    BiometricPromptManager.BiometricResult.AuthenticationSuccess -> "Authentication Success"
                    BiometricPromptManager.BiometricResult.AuthenticationNotSet -> {
                        if (Build.VERSION.SDK_INT >= 30) {
                            // Launch the biometric enrollment activity if not set
                            val enrollIntent = Intent(Settings.ACTION_BIOMETRIC_ENROLL).apply {
                                putExtra(
                                    Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED,
                                    BIOMETRIC_STRONG or DEVICE_CREDENTIAL
                                )
                            }
                            enrollLauncher.launch(enrollIntent)
                        }
                        "Authentication Not Set"
                    }
                    BiometricPromptManager.BiometricResult.FeatureUnavailable -> "Feature Unavailable"
                    BiometricPromptManager.BiometricResult.HardwareUnavailable -> "Hardware Unavailable"
                }
            }
        }

        // Handle the authenticate button click
        authenticateButton.setOnClickListener {
            promptManager.showBiometricPrompt(
                title = "Authenticate",
                description = "Please authenticate to continue"
            )
        }

        // Handle the toggle button logic
        toggleButton.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                // Enable biometric authentication (if needed)
                // You can implement any specific logic here
            } else {
                // Disable biometric authentication (if needed)
                // You can implement any specific logic here
            }
        }

        // Handle the back button click
        backButton.setOnClickListener {
            onBackPressed() // Navigate to the previous screen
        }
    }
}
