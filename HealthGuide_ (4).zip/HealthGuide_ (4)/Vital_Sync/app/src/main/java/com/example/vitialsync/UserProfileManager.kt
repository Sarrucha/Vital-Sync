package com.example.vitialsync


import android.content.Context
import android.content.SharedPreferences


class UserProfileManager(context: Context) {

    companion object {
        private const val PREF_NAME = "userProfile"
        private const val KEY_USERNAME = "username"
        private const val KEY_AGE = "age"
        private const val KEY_HEIGHT = "height"
        private const val KEY_WEIGHT = "weight"
    }

    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    // Function to save user profile data
    fun saveUserProfile(username: String, age: Int, height: Int, weight: Int) {
        with(sharedPreferences.edit()) {
            putString(KEY_USERNAME, username)
            putString(KEY_AGE, age.toString())
            putString(KEY_HEIGHT, height.toString())
            putString(KEY_WEIGHT, weight.toString())
            apply()
        }
    }

    // Function to get username
    fun getUsername(): String {
        return sharedPreferences.getString(KEY_USERNAME, "User") ?: "User"
    }

    // Function to get age
    fun getAge(): Int {
        return sharedPreferences.getString(KEY_AGE, "0")?.toIntOrNull() ?: 0
    }

    // Function to get height
    fun getHeight(): Int {
        return sharedPreferences.getString(KEY_HEIGHT, "0")?.toIntOrNull() ?: 0
    }

    // Function to get weight
    fun getWeight(): Int {
        return sharedPreferences.getString(KEY_WEIGHT, "0")?.toIntOrNull() ?: 0
    }

    // Function to clear user profile data
    fun clearUserProfile() {
        with(sharedPreferences.edit()) {
            clear()
            apply()
        }
    }
}