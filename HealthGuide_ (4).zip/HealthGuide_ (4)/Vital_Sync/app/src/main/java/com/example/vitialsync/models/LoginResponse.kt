package com.example.vitialsync.models

data class LoginResponse(
    val username: String,
    val password: String
)
