package com.example.vitialsync

import android.content.Context
import android.content.res.Configuration
import androidx.fragment.app.Fragment
import java.util.Locale

open class BaseFragment: Fragment() {

    override fun onAttach(context: Context) {
        super.onAttach(updateLocale(context, getSavedLocale(context)))
    }

    // Method to update the locale in the context
    private fun updateLocale(context: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)

        return context.createConfigurationContext(config)
    }

    // Method to retrieve the saved locale
    private fun getSavedLocale(context: Context): String {
        val sharedPreferences = context.getSharedPreferences("Settings", Context.MODE_PRIVATE)
        return sharedPreferences.getString("Selected_Language", "en") ?: "en" // Default to English
    }
}