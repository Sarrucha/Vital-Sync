package com.example.vitialsync.models

data class Customization(
    val userId: String,
    val language: String,
    val height: Float,
    val weight: Float,
    val fitnessGoal: String,
    val difficultyLevel: String
)
