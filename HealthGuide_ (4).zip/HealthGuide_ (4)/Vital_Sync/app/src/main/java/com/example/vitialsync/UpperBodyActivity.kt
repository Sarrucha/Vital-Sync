package com.example.vitialsync // Replace with your app's package name

import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.AlertDialog
//Code Attribution
//This code was referenced from JohnCodes
//https://johncodeos.com/how-to-create-a-popup-window-in-android-using-kotlin/
// The author name is John Codes
//https://johncodeos.com/author/johncod/
class UpperBodyActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upper_body) // Ensure this matches your XML file name

        // Back Button
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)
        backButton.setOnClickListener {
            onBackPressed()
        }

        // Show details dialog on image click
        val beginnerImage: ImageView = findViewById(R.id.imageBeginner)
        val intermediateImage: ImageView = findViewById(R.id.imageIntermediate)
        val advancedImage: ImageView = findViewById(R.id.imageAdvanced)

        beginnerImage.setOnClickListener {
            showDetailsDialog(getString(R.string.beginner_details_title), getString(R.string.beginner_details))
        }

        intermediateImage.setOnClickListener {
            showDetailsDialog(getString(R.string.intermediate_details_title), getString(R.string.intermediate_details))
        }

        advancedImage.setOnClickListener {
            showDetailsDialog(getString(R.string.advanced_details_title), getString(R.string.advanced_details))
        }
    }

    private fun showDetailsDialog(title: String, message: String) {
        val dialogBuilder = AlertDialog.Builder(this)
        dialogBuilder.setTitle(title)
        dialogBuilder.setMessage(message)
        dialogBuilder.setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
        dialogBuilder.show()
    }
}
