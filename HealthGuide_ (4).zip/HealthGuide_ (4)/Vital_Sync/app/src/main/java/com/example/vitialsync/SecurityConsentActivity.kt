package com.example.vitialsync

import android.os.Bundle
import android.widget.ImageButton

class SecurityConsentActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_security_consent)

        // Ensure this ID matches the one in the layout file
        val backButton: ImageButton = findViewById(R.id.ic_arrow_back)

        // Set click listener to handle back navigation
        backButton.setOnClickListener {
            onBackPressed()  // Navigate to the previous screen
        }
    }
}
